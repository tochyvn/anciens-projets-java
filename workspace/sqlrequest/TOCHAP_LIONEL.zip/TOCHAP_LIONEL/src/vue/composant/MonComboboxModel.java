package vue.composant;

import java.util.Vector;

import javax.swing.DefaultComboBoxModel;

public class MonComboboxModel extends DefaultComboBoxModel<String> {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public MonComboboxModel(Vector<String> string) {
		super(string);
	}
}
