package vue.composant;

import java.awt.LayoutManager;

import javax.swing.JPanel;

public class MonPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MonPanel() {
		
	}

	public MonPanel(LayoutManager layout) {
		super(layout);
	}


}
