package vue.composant;
/**
 * Interface de constantes
 * @author TOCHAP
 *@version 1.0.1
 */
public interface Constante {
	public static String[] DRIVERS = {"Drivers", "ODBC_DRIVER", "MYSQL_JDBC_DRIVERS", "SUN_DRIVERS"};
	public static String[] DATABASES = {"Databases", "TP1", "SITE_ENCHERES", "SCOLARITE", "TOCHYVN"};
}
