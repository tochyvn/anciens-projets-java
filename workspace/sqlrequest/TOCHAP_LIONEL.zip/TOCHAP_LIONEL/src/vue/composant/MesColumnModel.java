package vue.composant;

import javax.swing.table.DefaultTableColumnModel;

public class MesColumnModel extends DefaultTableColumnModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MesColumnModel() {
		
	}

	
}
