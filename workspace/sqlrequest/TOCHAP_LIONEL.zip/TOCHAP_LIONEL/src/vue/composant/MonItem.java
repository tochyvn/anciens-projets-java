package vue.composant;

import javax.swing.JMenuItem;

public class MonItem extends JMenuItem {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MonItem() {
		super();
	}

	public MonItem(String text) {
		super(text);
	}

}
