package vue.action;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


public class CloseListener extends WindowAdapter {

	public CloseListener() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosing(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub

	}

}
