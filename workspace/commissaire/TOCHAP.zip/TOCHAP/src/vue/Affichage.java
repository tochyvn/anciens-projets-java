package vue;
/**
 * Interface Affichage
 * @author TOCHAP 
 * @version v1.0
 */
public interface Affichage {

	void afficheProgress(int id, int position, String s);
	void affichageRebours(String s);
	
}
