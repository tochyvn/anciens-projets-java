package modele.metier;

public class Visibility {
	private int couleur;

	public Visibility() {
		this.couleur = 3;
	}
	
	public int getVisibily() {
		return couleur;
	}

}
