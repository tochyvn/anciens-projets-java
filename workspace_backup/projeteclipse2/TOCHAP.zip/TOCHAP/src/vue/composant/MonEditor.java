package vue.composant;

import javax.swing.JEditorPane;

public class MonEditor extends JEditorPane {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MonEditor() {
		super();
	}


}
