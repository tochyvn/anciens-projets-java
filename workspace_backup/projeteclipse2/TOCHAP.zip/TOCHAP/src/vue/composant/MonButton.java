package vue.composant;

import javax.swing.Icon;
import javax.swing.JButton;

public class MonButton extends JButton {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MonButton() {
		super();
	}

	public MonButton(String text) {
		super(text);
		
	}

	public MonButton(Icon icon) {
		super(icon);
		// TODO Auto-generated constructor stub
	}


}
