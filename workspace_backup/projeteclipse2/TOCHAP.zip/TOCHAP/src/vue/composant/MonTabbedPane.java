package vue.composant;

import java.util.ArrayList;

import javax.swing.JTabbedPane;

public class MonTabbedPane extends JTabbedPane {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MonTabbedPane() {
		super();
	}
	
}
