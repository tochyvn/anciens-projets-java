package vue.composant;

import java.awt.Component;

import javax.swing.JScrollPane;

public class MonScrollPane extends JScrollPane {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MonScrollPane() {
		super();
	}

	public MonScrollPane(Component view) {
		super(view);
		
	}

}
