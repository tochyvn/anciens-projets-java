package vue.ecouteurs;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class OnChangeListener implements ChangeListener {

	public OnChangeListener() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void stateChanged(ChangeEvent e) {
		System.out.println("dgyhjfjkjh");

	}

}
