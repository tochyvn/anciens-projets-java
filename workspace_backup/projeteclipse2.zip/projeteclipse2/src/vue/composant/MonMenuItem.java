package vue.composant;

import javax.swing.JMenuItem;

public class MonMenuItem extends JMenuItem {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MonMenuItem() {
		super();
	}

	public MonMenuItem(String text) {
		super(text);
		setVisible(true);
	}

}
